<?php // login.php
  $hm = 'localhost';
  $db = 'j716560_teografe';
  $un = '046705032_teogr';
  $pw = 'a5arakara4ukara';
?>