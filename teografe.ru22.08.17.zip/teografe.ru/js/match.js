jQuery(document).ready(function(xTest){
        $("#by-strong").on('change', function () {
$("#input").attr("maxlength","4");
});
         
});